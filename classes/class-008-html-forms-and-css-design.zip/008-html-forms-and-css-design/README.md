# Class 008 — HTML Forms & CSS Form Design

## What you will learn

1. The structure of a real HTML form
2. `label`, `input`, `textarea`, `select`, `button`
3. Text, email, password, number, date, radio, checkbox, and file inputs
4. `name`, `id`, `required`, `autocomplete`, `minlength`, and `pattern`
5. `fieldset` and `legend`
6. Native browser validation
7. Mobile-first form layout with CSS Grid
8. Focus, hover, valid, and invalid states
9. Accessible labels and keyboard-friendly controls
10. Practical form design and visual hierarchy

## Student workflow

Open the source in the Smart Editor, change the form, and watch the Live Preview. Try changing one idea at a time so you can see exactly what each change does.

## Mentor rule

Do not start by making a form look beautiful. Start by making it correct. Semantic HTML → accessibility → validation → layout → visual polish → JavaScript enhancement.

## Homework

Build a responsive registration form from scratch.

Minimum requirements:
- Full name
- Email
- Password
- Date of birth
- Radio group
- Checkbox group
- Select menu
- Textarea
- Submit and reset buttons
- Native validation
- Visible labels
- Mobile-first CSS
- Focus and invalid states

### Extra challenge

Add a disabled state, helper text, a success message, and a clean desktop/mobile layout.
