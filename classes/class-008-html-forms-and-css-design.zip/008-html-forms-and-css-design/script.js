const form = document.querySelector('#feedbackForm');
const formMessage = document.querySelector('#formMessage');
const challengeButton = document.querySelector('#challengeButton');
const challengeMessage = document.querySelector('#challengeMessage');

form?.addEventListener('submit', (event) => {
  event.preventDefault();
  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }
  const name = String(new FormData(form).get('fullName') || 'Student').trim();
  formMessage.textContent = `Nice work, ${name}! The browser accepted your form and native validation passed.`;
});

form?.addEventListener('reset', () => {
  window.setTimeout(() => { if (formMessage) formMessage.textContent = ''; }, 0);
});

challengeButton?.addEventListener('click', () => {
  const checks = [...document.querySelectorAll('.checks input')];
  const done = checks.filter((item) => item.checked).length;
  challengeMessage.textContent = done === checks.length
    ? 'Challenge complete. Now rebuild the form without looking at the demo.'
    : `You completed ${done}/${checks.length}. Finish the checklist, then build your own version.`;
});
